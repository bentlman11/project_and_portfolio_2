﻿using System;

namespace DataConvsersion
{
    class Program
    {
        private static Program _instance;

        static void Main(string[] args)
        {
            
            _instance = new Program();

            bool programIsRunning = true;

            //Greet the user
            Console.WriteLine("Hello Admin, What Would You Like To Do Today?");

            //loop through this functionality while program is running.
            while (programIsRunning)
            {
                _instance.MainMenu();

                int selection = Validation.GetInt(0,1,"Please enter your selection number: ");

                switch (selection)
                {
                    case 1:
                        {
                            //If choice was 1, // ConversionToJSON.ConvertSQL();

                            ConversionToJSON.ConvertSQL();
                        }
                        break;
                    case 0:
                        {
                            programIsRunning = false;
                        }
                        break;
                }

                
            }

            Console.WriteLine("");
            Console.WriteLine("Goodbye Admin. ");
            Utility.WaitForKey("Press any key to exit...");
        }

        //Prints the Main menu to the console.
        private void MainMenu()
        {
            Console.WriteLine("");
            Console.WriteLine("1. Convert The Restaurant Profile Table From SQL To JSON");
            Console.WriteLine("2. Showcase Our 5 Star Rating System");
            Console.WriteLine("3. Showcase Our Animated Bar Graph Review System");
            Console.WriteLine("4. Play A Card Game");
            Console.WriteLine("5. Exit");
            Console.WriteLine("");
        }

       
    }
}
