﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data.MySqlClient;

namespace DataConvsersion
{
    class Utility
    {
        public static void WaitForKey(string message)
        {
            Console.WriteLine("");
            Console.WriteLine(message);
            Console.ReadKey();
        }

        public static string NullChecker(MySqlDataReader rdr, int columnNumber)
        {
            if (!rdr.IsDBNull(columnNumber))
            {
                return rdr.GetString(columnNumber).ToLower();
            }
            return "null";
        }
    }
}
