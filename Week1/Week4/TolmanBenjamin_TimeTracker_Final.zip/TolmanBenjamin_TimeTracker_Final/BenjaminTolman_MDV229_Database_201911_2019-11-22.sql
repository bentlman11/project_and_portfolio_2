# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.7.26)
# Database: BenjaminTolman_MDV229_Database_201911
# Generation Time: 2019-11-22 22:08:26 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table activity_categories_table
# ------------------------------------------------------------

DROP TABLE IF EXISTS `activity_categories_table`;

CREATE TABLE `activity_categories_table` (
  `activity_category_id` int(11) NOT NULL,
  `category_description` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`activity_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `activity_categories_table` WRITE;
/*!40000 ALTER TABLE `activity_categories_table` DISABLE KEYS */;

INSERT INTO `activity_categories_table` (`activity_category_id`, `category_description`)
VALUES
	(1,'workingout'),
	(2,'work'),
	(3,'schoolwork'),
	(4,'sleep'),
	(5,'relaxing'),
	(6,'family');

/*!40000 ALTER TABLE `activity_categories_table` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table activity_descriptions_table
# ------------------------------------------------------------

DROP TABLE IF EXISTS `activity_descriptions_table`;

CREATE TABLE `activity_descriptions_table` (
  `activity_description_id` int(11) NOT NULL,
  `activity_description` varchar(25) NOT NULL,
  PRIMARY KEY (`activity_description_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `activity_descriptions_table` WRITE;
/*!40000 ALTER TABLE `activity_descriptions_table` DISABLE KEYS */;

INSERT INTO `activity_descriptions_table` (`activity_description_id`, `activity_description`)
VALUES
	(1,'Go for a Run'),
	(2,'Do Calisthenics'),
	(3,'Doing School Work'),
	(4,'Study'),
	(5,'Do Programming'),
	(6,'Do 3D Modeling'),
	(7,'Sleep'),
	(8,'Walk'),
	(9,'Watching Movie'),
	(10,'Play Video Game'),
	(11,'Driving');

/*!40000 ALTER TABLE `activity_descriptions_table` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table activity_log_table
# ------------------------------------------------------------

DROP TABLE IF EXISTS `activity_log_table`;

CREATE TABLE `activity_log_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `calendar_day` int(11) NOT NULL,
  `calendar_date` int(11) NOT NULL,
  `day_name` int(11) NOT NULL,
  `category_description` int(11) NOT NULL,
  `activity_description` int(11) NOT NULL,
  `time_spent_on_activity` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `numericalDay_idx` (`calendar_day`),
  KEY `date_idx` (`calendar_date`),
  KEY `dayOfWeek_idx` (`day_name`),
  KEY `timeSpent_idx` (`time_spent_on_activity`),
  KEY `activityDescription_idx` (`activity_description`),
  KEY `activityCatagory_idx` (`category_description`),
  KEY `user_idx` (`user_id`),
  CONSTRAINT `Users` FOREIGN KEY (`user_id`) REFERENCES `time_tracker_users_table` (`user_id`),
  CONSTRAINT `activityCategories` FOREIGN KEY (`category_description`) REFERENCES `activity_categories_table` (`activity_category_id`) ON UPDATE CASCADE,
  CONSTRAINT `activityDescription` FOREIGN KEY (`activity_description`) REFERENCES `activity_descriptions_table` (`activity_description_id`),
  CONSTRAINT `date` FOREIGN KEY (`calendar_date`) REFERENCES `tracked_calendar_dates_table` (`calendar_date_id`),
  CONSTRAINT `dayOfWeek` FOREIGN KEY (`day_name`) REFERENCES `days_of_week_table` (`day_id`),
  CONSTRAINT `numericalDay` FOREIGN KEY (`calendar_day`) REFERENCES `tracked_calendar_days_table` (`calendar_day_id`),
  CONSTRAINT `timeSpent` FOREIGN KEY (`time_spent_on_activity`) REFERENCES `activity_times_table` (`activity_time_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `activity_log_table` WRITE;
/*!40000 ALTER TABLE `activity_log_table` DISABLE KEYS */;

INSERT INTO `activity_log_table` (`id`, `calendar_day`, `calendar_date`, `day_name`, `category_description`, `activity_description`, `time_spent_on_activity`, `user_id`)
VALUES
	(1,1,1,5,1,2,4,1),
	(2,1,1,5,6,12,2,1),
	(3,1,1,5,16,10,3,1),
	(4,1,1,5,12,12,2,1),
	(5,1,1,5,5,12,1,1),
	(6,2,2,6,1,2,1,1),
	(7,2,2,6,16,12,1,1),
	(8,3,3,7,1,7,1,1),
	(9,3,3,7,16,10,1,1),
	(10,8,8,5,2,2,3,1),
	(11,8,8,5,2,2,3,1),
	(12,8,8,5,13,12,2,1),
	(13,9,9,6,17,12,2,1),
	(14,9,9,6,6,12,2,1),
	(15,9,9,6,7,2,3,1),
	(16,10,10,7,7,12,1,1),
	(17,10,10,7,9,1,1,1),
	(18,14,14,4,18,12,2,1),
	(19,14,14,4,14,3,2,1),
	(20,14,14,4,14,2,1,1),
	(21,14,14,4,18,10,1,1),
	(22,14,14,4,14,8,2,1),
	(23,15,15,5,14,3,2,1),
	(24,15,15,5,14,2,3,1),
	(25,15,15,5,14,1,3,1),
	(26,17,17,7,14,3,8,1),
	(27,17,17,7,15,12,1,1),
	(28,18,18,1,4,2,2,1),
	(29,18,18,1,7,2,2,1),
	(30,18,18,1,7,3,1,1),
	(31,19,19,2,11,12,2,1),
	(32,20,20,3,19,4,1,1),
	(33,20,20,3,7,2,2,1),
	(34,20,20,3,7,4,1,1);

/*!40000 ALTER TABLE `activity_log_table` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table activity_times_table
# ------------------------------------------------------------

DROP TABLE IF EXISTS `activity_times_table`;

CREATE TABLE `activity_times_table` (
  `activity_time_id` int(11) NOT NULL,
  `time_spent_on_activity` double NOT NULL,
  PRIMARY KEY (`activity_time_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `activity_times_table` WRITE;
/*!40000 ALTER TABLE `activity_times_table` DISABLE KEYS */;

INSERT INTO `activity_times_table` (`activity_time_id`, `time_spent_on_activity`)
VALUES
	(1,0.25),
	(2,0.5),
	(3,0.75),
	(4,1),
	(5,1.25),
	(6,1.5),
	(7,1.75),
	(8,2),
	(9,2.25),
	(10,2.5),
	(11,2.75),
	(12,3),
	(13,3.25),
	(14,3.5),
	(15,3.75),
	(16,4),
	(17,4.25),
	(18,4.5),
	(19,4.75),
	(20,5),
	(21,5.25),
	(22,5.5),
	(23,5.75),
	(24,6),
	(25,6.25),
	(26,6.5),
	(27,6.75),
	(28,7),
	(29,7.25),
	(30,7.5),
	(31,7.75),
	(32,8),
	(33,8.25),
	(34,8.5),
	(35,8.75),
	(36,9),
	(37,9.25),
	(38,9.5),
	(39,9.75),
	(40,10),
	(41,10.25),
	(42,10.5),
	(43,10.75),
	(44,11),
	(45,11.25),
	(46,11.5),
	(47,11.75),
	(48,12),
	(49,12.25),
	(50,12.5),
	(51,12.75),
	(52,13),
	(53,13.25),
	(54,13.5),
	(55,13.75),
	(56,14),
	(57,14.25),
	(58,14.5),
	(59,14.75),
	(60,15),
	(61,15.25),
	(62,15.5),
	(63,15.75),
	(64,16),
	(65,16.25),
	(66,16.5),
	(67,16.75),
	(68,17),
	(69,17.25),
	(70,17.5),
	(71,17.75),
	(72,18),
	(73,18.25),
	(74,18.5),
	(75,18.75),
	(76,19),
	(77,19.25),
	(78,19.5),
	(79,19.75),
	(80,20),
	(81,20.25),
	(82,20.5),
	(83,20.75),
	(84,21),
	(85,21.25),
	(86,21.5),
	(87,21.75),
	(88,22),
	(89,22.25),
	(90,22.5),
	(91,22.75),
	(92,23),
	(93,23.25),
	(94,23.5),
	(95,24);

/*!40000 ALTER TABLE `activity_times_table` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table days_of_week_table
# ------------------------------------------------------------

DROP TABLE IF EXISTS `days_of_week_table`;

CREATE TABLE `days_of_week_table` (
  `day_id` int(11) NOT NULL,
  `day_name` varchar(10) NOT NULL,
  PRIMARY KEY (`day_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `days_of_week_table` WRITE;
/*!40000 ALTER TABLE `days_of_week_table` DISABLE KEYS */;

INSERT INTO `days_of_week_table` (`day_id`, `day_name`)
VALUES
	(1,'monday'),
	(2,'tuesday'),
	(3,'wednesday'),
	(4,'thursday'),
	(5,'friday'),
	(6,'saturday'),
	(7,'sunday');

/*!40000 ALTER TABLE `days_of_week_table` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table time_tracker_users_table
# ------------------------------------------------------------

DROP TABLE IF EXISTS `time_tracker_users_table`;

CREATE TABLE `time_tracker_users_table` (
  `user_id` int(11) NOT NULL,
  `user_password` varchar(10) NOT NULL,
  `user_firstname` varchar(25) NOT NULL,
  `user_lastname` varchar(45) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `time_tracker_users_table` WRITE;
/*!40000 ALTER TABLE `time_tracker_users_table` DISABLE KEYS */;

INSERT INTO `time_tracker_users_table` (`user_id`, `user_password`, `user_firstname`, `user_lastname`)
VALUES
	(1,'password','studentFirst','studentLast'),
	(2,'password','admin','admin'),
	(3,'password','instructor','instructor');

/*!40000 ALTER TABLE `time_tracker_users_table` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tracked_calendar_dates_table
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tracked_calendar_dates_table`;

CREATE TABLE `tracked_calendar_dates_table` (
  `calendar_date_id` int(11) NOT NULL,
  `calendar_date` date NOT NULL,
  PRIMARY KEY (`calendar_date_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `tracked_calendar_dates_table` WRITE;
/*!40000 ALTER TABLE `tracked_calendar_dates_table` DISABLE KEYS */;

INSERT INTO `tracked_calendar_dates_table` (`calendar_date_id`, `calendar_date`)
VALUES
	(1,'2019-11-01'),
	(2,'2019-11-02'),
	(3,'2019-11-03'),
	(4,'2019-11-04'),
	(5,'2019-11-05'),
	(6,'2019-11-06'),
	(7,'2019-11-07'),
	(8,'2019-11-08'),
	(9,'2019-11-09'),
	(10,'2019-11-10'),
	(11,'2019-11-11'),
	(12,'2019-11-12'),
	(13,'2019-11-13'),
	(14,'2019-11-14'),
	(15,'2019-11-15'),
	(16,'2019-11-16'),
	(17,'2019-11-17'),
	(18,'2019-11-18'),
	(19,'2019-11-19'),
	(20,'2019-11-20'),
	(21,'2019-11-21'),
	(22,'2019-11-22'),
	(23,'2019-11-23'),
	(24,'2019-11-24'),
	(25,'2019-11-25'),
	(26,'2019-11-26');

/*!40000 ALTER TABLE `tracked_calendar_dates_table` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tracked_calendar_days_table
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tracked_calendar_days_table`;

CREATE TABLE `tracked_calendar_days_table` (
  `calendar_day_id` int(11) NOT NULL,
  `calendar_numerical_day` int(11) NOT NULL,
  PRIMARY KEY (`calendar_day_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `tracked_calendar_days_table` WRITE;
/*!40000 ALTER TABLE `tracked_calendar_days_table` DISABLE KEYS */;

INSERT INTO `tracked_calendar_days_table` (`calendar_day_id`, `calendar_numerical_day`)
VALUES
	(1,5),
	(2,6),
	(3,7),
	(4,1),
	(5,2),
	(6,3),
	(7,4),
	(8,5),
	(9,6),
	(10,7),
	(11,1),
	(12,2),
	(13,3),
	(14,4),
	(15,5),
	(16,6),
	(17,7),
	(18,1),
	(19,2),
	(20,3),
	(21,4),
	(22,5),
	(23,6),
	(24,7),
	(25,1),
	(26,2);

/*!40000 ALTER TABLE `tracked_calendar_days_table` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
