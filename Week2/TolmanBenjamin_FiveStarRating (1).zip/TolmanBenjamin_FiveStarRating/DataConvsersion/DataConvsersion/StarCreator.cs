﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataConvsersion
{
    class StarCreator
    {
        private static string[] _stars = new string[] { "", "*", "**", "***", "****", "*****" };

        public static void StarCreation(double rating)
        {
            int starCount = Convert.ToInt32(rating);
            if(starCount <= 2.0){Console.ForegroundColor = ConsoleColor.DarkRed;}
            else if(starCount == 3.0) { Console.ForegroundColor = ConsoleColor.DarkYellow; }
            else if (starCount >= 4.0) { Console.ForegroundColor = ConsoleColor.DarkGreen; }
            Console.Write($"{_stars[starCount]} ");//Write and color change insine StarCreator.
            Console.ResetColor();
        }
    }
}
