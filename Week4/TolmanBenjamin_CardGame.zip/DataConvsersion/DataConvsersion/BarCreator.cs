﻿using System;
using System.Timers;
using System.Collections.Generic;
using System.Text;

namespace DataConvsersion
{
    class BarCreator
    {
        //Declalir a Timer
        private static Timer timer;
        private static int timerCounter;
        private static double _currentScore;
        
        public static double CurrentScore
        {
            get { return _currentScore; } set { _currentScore = value; }
        }
        
        public static void CreateRandomBar()
        {
            timerCounter = 0;
            //Set time to happen really fast 1,000 = 1 second
            //Start the function every 1000/1000 seconds
            timer = new Timer(50);

            //At 50/1000, run this method "OnTimedEvent"
            //Every time it elapses, do it
            timer.Elapsed += OnTimedEvent;

            //Reset timer again after 50/1000, over and over again
            //False means to only run the timer one time
            timer.AutoReset = true;

            //The timer is enabled so it will work
            //False means the timer will not work
            timer.Enabled = true;
        }

        //Timer Method that runs every time the timer elapses
        private static void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            //turn off the curser
            Console.CursorVisible = false;

            //Setting the bar graph colors
            ConsoleColor myBackgroundColor = ConsoleColor.Gray;
            ConsoleColor myBarGraphColor = ConsoleColor.Blue;

            //Add one to the timer counter
            timerCounter++;

            //Random number for the bar graph animation
            Random myRandomNumber = new Random();

            //This randomly selects a number from 0 to 10 and assigns it to a variable.
            //0 and 10 could be any number, but we want the bar graph to be 10 spaces long
            //...think a rating of 8/10.
            //We will randomize it over and over to get the animation
            int theRating = myRandomNumber.Next(0, 11);

            //Create bar graph, not the bar graph background
            //We create the bar we want first, and the background second.
            for (int ii = 0; ii <= theRating; ii++)
            {
                //set Background color to variable 
                Console.BackgroundColor = myBarGraphColor;
                //This creates a colored bar graph of spaces, so if you have a 5/10, you will get 5 colored spaces.
                Console.Write(" ");
            }

            //Set total number for the length of the bar graph, which is also the background
            int barMaxSize = 10;

            //Draw bar graph background
            //The background is not seen around the edges of the bar, or also with the foreground color of the bar. We only see one color at a time.
            //So, we just start drawing the background after the final drawing of the bar graph based on the data.
            //For Example...if we have 5/10, then the bar graph is 1-5 and the background is 6-10.
            for (int iii = theRating; iii <= barMaxSize; iii++)
            {
                //We could run the below code here if we wanted, but we just set it once above instead of each time here.
                Console.BackgroundColor = myBackgroundColor;
                //This creates a colored background of spaces, so if you have a 5/10, you will get 5 colored spaces to make the background after the 5 colored spaces that made up the bar.
                Console.Write(" ");
            }
            //Move the cursor back to the left, where it started to draw the animation to begin with.
            //Once we redraw, and redraw, and redraw, it will look animated.
            //We are doing this because we are uisng a Console.Write to stay on the same line, so we move back, and redraw over top of the old one.
            Console.CursorLeft = 0;

            //TODO if timer counter == 49 then set the cotrrect value or
            if (timerCounter == 50)
            {
                //Stop Timer
                timer.Stop();

                CreateStaticBar(_currentScore);
                
                //Move the cursor down and away from the artwork/bar graph to have menu options, text, etc.
                for (int x = 0; x < 2; x++)
                {
                    Console.WriteLine("");
                }

                Console.BackgroundColor = ConsoleColor.Black;
                //Show the cursor again so the user can do what you need them to do.
                Console.CursorVisible = true;
                
                //Console.WriteLine("Press Space to Continue to Menu.");
                //Console.ReadKey();
            }
        }
        
        public static void CreateStaticBar(double rating)
        {

            ConsoleColor myBackgroundColor = ConsoleColor.DarkGray;
            ConsoleColor myBarGraphColor = ConsoleColor.Magenta;

            if (rating <= 3) { myBarGraphColor = ConsoleColor.Red; }
            if (rating >= 3.1 && rating <= 6.1) { myBarGraphColor = ConsoleColor.Yellow; }
            if (rating >= 6.9) { myBarGraphColor = ConsoleColor.Green; }
            
            int intRating = Convert.ToInt32(rating);
            
            //Create bar graph, not the bar graph background
            //We create the bar we want first, and the background second.
            for (int i = 0; i <= intRating; i++)
            {
                //set Background color to variable 
                Console.BackgroundColor = myBarGraphColor;
                //This creates a colored bar graph of spaces, so if you have a 5/10, you will get 5 colored spaces.
                Console.Write(" ");
            }

            //Set total number for the length of the bar graph, which is also the background
            int barMaxSize = 10;

            //Draw bar graph background
            //The background is not seen around the edges of the bar, or also with the foreground color of the bar. We only see one color at a time.
            //So, we just start drawing the background after the final drawing of the bar graph based on the data.
            //For Example...if we have 5/10, then the bar graph is 1-5 and the background is 6-10.
            
            for (int ii = intRating; ii <= barMaxSize; ii++)
            {
                //We could run the below code here if we wanted, but we just set it once above instead of each time here.
                Console.BackgroundColor = myBackgroundColor;
                //This creates a colored background of spaces, so if you have a 5/10, you will get 5 colored spaces to make the background after the 5 colored spaces that made up the bar.
                Console.Write(" ");
            }

            Console.ResetColor();
        }
    }
}
