﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using MySql.Data.MySqlClient;

namespace DataConvsersion
{
    class DatabaseConnection
    {
        private MySqlConnection connection;
        private string server;
        private string database;
        private string uid;
        private string password;

        private string _currentUser = "";
        //private static DatabaseConnection _instance = new DatabaseConnection();

        public string CurrentUser { get { return _currentUser; } }

        public DatabaseConnection()
        {
            Initialize();
        }

        //Initialize values
        private void Initialize()
        {
            // MySQL Database Connection String
            string cs = @"server=192.168.201.1;userid=dbremoteuser;password=password;database=samplerestaurantdatabase;port=8889";

            //string cs = @"server= 127.0.0.1;userid=root;password=root;database=SampleRestaurantDatabase;port=8889";
            //Output Location
            //string outputFolder = @"../../output/";﻿﻿

            connection = new MySqlConnection(cs);

            GetName();
        }

        public string GetPlayer(int playerId)
        {
            OpenConnection();

            MySqlDataReader rdr = null;

            // Prepare SQL Statement
            
            string stm = $"Select first, last from restaurantReviewers where id = {playerId};";

            MySqlCommand cmd = new MySqlCommand(stm, connection);

            //Execute SQL Statement
            using (rdr = cmd.ExecuteReader())
            {
                string playerName = "";
                while (rdr.Read())
                {
                   playerName = ($"{Utility.NullChecker(rdr, 0)} {Utility.NullChecker(rdr, 1)}");
                }

                CloseConnection();
                return playerName;
            }
        }
        public string GetName()
        {
            OpenConnection();

            MySqlDataReader rdr = null;

            // Prepare SQL Statement
            //string stm = "select restaurantName, reviewScore from restaurantProfiles inner join restaurantReviews on restaurantProfiles.id = restaurantReviews.restaurantId";

            string stm = "SELECT CURRENT_USER";

            MySqlCommand cmd = new MySqlCommand(stm, connection);

            //Execute SQL Statement
            using (rdr = cmd.ExecuteReader())
            {
                while (rdr.Read())
                {
                    _currentUser = Utility.NullChecker(rdr, 0);
                }

                CloseConnection();
                return _currentUser;
            }
        }

        //TODO
        //open connection to database
        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {

                switch (ex.Number)
                {
                    case 0:
                        Console.WriteLine("Cannot connect to server.");
                        break;

                    case 1045:
                        Console.WriteLine("Invalid username/password.");
                        break;
                }
                return false;
            }
        }

        //Close connection
        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }

        public void SelectReviews(int sortStyle, double viewLimit, int style)
        {
            OpenConnection();

            MySqlDataReader rdr = null;

            // Prepare SQL Statement
            //string stm = "select restaurantName, reviewScore from restaurantProfiles inner join restaurantReviews on restaurantProfiles.id = restaurantReviews.restaurantId";

            string stm = "select restaurantName, overallRating from restaurantProfiles";

            MySqlCommand cmd = new MySqlCommand(stm, connection);

            //Execute SQL Statement
            using (rdr = cmd.ExecuteReader())
            {
                Dictionary<string, Restaurant> restaurantDic = new Dictionary<string, Restaurant>();

                while (rdr.Read())
                {
                    Restaurant restaurant = new Restaurant(Utility.NullChecker(rdr, 0), Utility.NullCheckerInt(rdr, 1));

                    restaurantDic.Add(restaurant.Name, restaurant);
                }


                List<Restaurant> restaurantList = new List<Restaurant>();

                foreach (KeyValuePair<string, Restaurant> entry in restaurantDic)
                {
                    restaurantList.Add(entry.Value);
                }

                switch (sortStyle)
                {
                    case 1:
                        {
                            Console.Clear();
                            restaurantList.Sort((x, y) => string.Compare(x.Name, y.Name));
                        }
                        break;
                    case 2:
                        {
                            Console.Clear();
                            restaurantList.Sort((x, y) => string.Compare(y.Name, x.Name));
                        }
                        break;
                    case 3:
                        {
                            Console.Clear();
                            restaurantList.Sort(Restaurant.SortRatingDescending());
                        }
                        break;
                    case 4:
                        {
                            Console.Clear();
                            restaurantList.Sort(Restaurant.SortRatingAscending());
                        }
                        break;
                }


                foreach (Restaurant entry in restaurantList)
                {
                    if (style == 1) //greater than
                    {
                        if (entry.Rating >= viewLimit)
                        {
                            string tName = entry.Name;
                            Console.Write($"\r\n {tName.PadRight(40, '-')} ");
                            StarCreator.StarCreation(entry.Rating);
                            Console.WriteLine("");
                        }
                    }
                    else if (style == 2) // less than
                    {
                        if (entry.Rating <= viewLimit)
                        {
                            string tName = entry.Name;
                            Console.Write($"\r\n {tName.PadRight(40, '-')} ");
                            StarCreator.StarCreation(entry.Rating);
                            Console.WriteLine("");
                        }
                    }

                    else if (style == 3) //==
                    {
                        if (entry.Rating == viewLimit)
                        {
                            string tName = entry.Name;
                            Console.Write($"\r\n {tName.PadRight(40, '-')} ");
                            StarCreator.StarCreation(entry.Rating);
                            Console.WriteLine("");
                        }
                    }

                }

                CloseConnection();
            }
        }

        //Select Bars
        public void SelectBars(int sortStyle, double viewLimit, int style, int resturnStyle) 
        {
            OpenConnection();

            MySqlDataReader rdr = null;

            // Prepare SQL Statement
            string stm = "select restaurantName, reviewScore from restaurantProfiles inner join restaurantReviews on restaurantProfiles.id = restaurantReviews.restaurantId";
            
            MySqlCommand cmd = new MySqlCommand(stm, connection);

            //Execute SQL Statement
            using (rdr = cmd.ExecuteReader())
            {
                Dictionary<string, Restaurant> restaurantDic = new Dictionary<string, Restaurant>();

                while (rdr.Read())
                {
                    Restaurant restaurant = new Restaurant(Utility.NullChecker(rdr, 0), Utility.NullCheckerDouble(rdr, 1));
                    restaurant.Ratings.Add(Utility.NullCheckerDouble(rdr, 1));
                    Restaurant temp;

                     if (restaurantDic.TryGetValue(restaurant.Name, out temp))
                     {
                         temp.Ratings.Add(Utility.NullCheckerDouble(rdr, 1));
                     }
                     else
                     {
                        restaurantDic.Add(restaurant.Name, restaurant);
                     }
                }
                
                double finalRating;
                double averageRating;

                List<Restaurant> restaurantList = new List<Restaurant>();

                foreach (KeyValuePair<string, Restaurant> entry in restaurantDic)
                {
                    restaurantList.Add(entry.Value);
                    entry.Value.Rating = entry.Value.GetAverage();
                }

                switch (sortStyle)
                {
                    case 1:
                        {
                            restaurantList.Sort((x, y) => string.Compare(x.Name, y.Name));
                        }
                        break;
                    case 2:
                        {
                            restaurantList.Sort((x, y) => string.Compare(y.Name, x.Name));
                        }
                        break;
                    case 3:
                        {
                            restaurantList.Sort(Restaurant.SortRatingDescending());
                        }
                        break;
                    case 4:
                        {
                            restaurantList.Sort(Restaurant.SortRatingAscending());
                        }
                        break;
                }

                if(resturnStyle == 1) //return all
                {
                    foreach (Restaurant entry in restaurantList)
                    {
                        finalRating = entry.GetFinalRating();
                        averageRating = entry.GetAverage();
                        Console.Write($"{entry.Name.PadRight(40, '-')} {averageRating.ToString("0.00")}  "); BarCreator.CreateStaticBar(finalRating);
                        Console.WriteLine("");
                    }
                }

                if (resturnStyle == 2) //2 = dinner spinner
                {
                    Random randomRestaurant = new Random();
                    
                    int randomRestaurantNumber = randomRestaurant.Next(0, restaurantList.Count);
                    
                    finalRating = restaurantList[randomRestaurantNumber].GetFinalRating();
                    averageRating = restaurantList[randomRestaurantNumber].GetAverage();
                    Console.WriteLine("");

                    Console.Write($"{restaurantList[randomRestaurantNumber].Name.PadRight(10, '-')} {averageRating.ToString("0.00")}  ");
                    BarCreator.CurrentScore = finalRating;  BarCreator.CreateRandomBar();
                    Console.WriteLine("");
                    
                }

                if (resturnStyle == 3) //return top 10 scores
                {
                    int counter = 0;

                    while(counter <= 10)
                    {
                        Restaurant temp = restaurantList[counter];
                        finalRating = temp.GetFinalRating();
                        averageRating = temp.GetAverage();
                        Console.Write($"{temp.Name.PadRight(40, '-')} {averageRating.ToString("0.00")}  "); BarCreator.CreateStaticBar(finalRating);
                        Console.WriteLine("");
                        counter++;
                    }
                    
                }

                CloseConnection();
            }
        }
    }
}
