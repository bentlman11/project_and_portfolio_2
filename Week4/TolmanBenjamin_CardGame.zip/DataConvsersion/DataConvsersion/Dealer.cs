﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataConvsersion
{
    class Dealer
    {
        
    }
}
