﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataConvsersion
{
    class Player : IComparer<Player>
    {
        private string _playerName = "";
        //create cards
        List<int> _cards = new List<int>();

        public List<int> Cards { get { return _cards; } set { _cards = value; } }
        public string PlayerName { get { return _playerName; } set { _playerName = value; } }

        //get score
        public int Score()
        {
            int scoreInt = 0;
            foreach (int card in _cards)
            {
                scoreInt += card;
            }

            return scoreInt;
        }
        public static IComparer<Player> SortRatingAscending()
        {
            return new SortRatingAscendingHelper();
        }
        public static IComparer<Player> SortRatingDescending()
        {
            return new SortRatingDescendingHelper();
        }

        int IComparer<Player>.Compare(Player a, Player b)
        {
            Player r1 = a;
            Player r2 = b;

            if (r1.Score() > r2.Score())
                return 1;

            if (r1.Score() < r2.Score())
                return -1;

            else
                return 0;
        }

        public class SortRatingAscendingHelper : IComparer<Player>
        {
            int IComparer<Player>.Compare(Player a, Player b)
            {
                Player r1 = a;
                Player r2 = b;

                if (r1.Score() > r2.Score())
                    return 1;

                if (r1.Score() < r2.Score())
                    return -1;

                else
                    return 0;
            }
        }

        public class SortRatingDescendingHelper : IComparer<Player>
        {
            int IComparer<Player>.Compare(Player a, Player b)
            {
                Player r1 = a;
                Player r2 = b;

                if (r1.Score() < r2.Score())
                    return 1;

                if (r1.Score() > r2.Score())
                    return -1;

                else
                    return 0;
            }
        }
    }
}
