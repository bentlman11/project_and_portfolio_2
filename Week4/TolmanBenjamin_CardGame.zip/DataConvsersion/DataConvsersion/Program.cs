﻿using System;
using System.Collections.Generic;
using System.Timers;

namespace DataConvsersion
{
    class Program
    {
        private static Program _instance;
        private static List<Restaurant> restaurants = new List<Restaurant>();
        private static DatabaseConnection DBconnection = new DatabaseConnection();

        static void Main(string[] args)
        {

            _instance = new Program();

            bool programIsRunning = true;

            while (programIsRunning)
            {
                Console.Clear();

                _instance.MainMenu();

                int selection = Validation.GetInt(0, 2, "Please enter your selection number: ");

                switch (selection)
                {
                    case 1:
                        {
                            ConvertJSON.ConvertSQL();
                        }
                        break;
                    case 2:
                        {
                            //Enter the star rating system
                            _instance.RatingSystemMenu();
                        }
                        break;
                    case 3:
                        {
                            //enter the bar system
                            _instance.BarGraphMenu();
                        }
                        break;
                    case 4:
                        {
                            //play card game
                            _instance.PlayCardGame();
                        }
                        break;

                    case 0:
                        {
                            programIsRunning = false;
                        }
                        break;
                }
            }

            Console.WriteLine("");
            Console.WriteLine("Farewell Admin. ");
            Utility.WaitForKey("Press any key to exit...");
        }

        private void MainMenu()
        {
            Console.WriteLine("");
            Console.WriteLine("Hello Admin, What Activity Would You Like To Do?");
            Console.WriteLine("");
            Console.WriteLine("1. I Want to Convert The Restaurant Profile Table From SQL To JSON");
            Console.WriteLine("2. Showcase Our 5 Star Rating System Please");
            Console.WriteLine("3. Showcase Our Animated Bar Graph Review System Please");
            Console.WriteLine("4. Play A Card Game Please");
            Console.WriteLine("0. Exit");
            Console.WriteLine("");
        }

        private void BarGraphMenu()
        {
            bool isBarMenu = true;

            while (isBarMenu)
            {



                Console.WriteLine("");
                Console.WriteLine($"Ok {DBconnection.CurrentUser}, how would you like to display the data?");

                Console.WriteLine("");
                Console.WriteLine("1. Show Average of reviews for restaurants.");
                Console.WriteLine("2. Dinner Spinner (Select Random Restaurant).");
                Console.WriteLine("3. Top 10 Restaurants.");
                Console.WriteLine("0. Back");
                Console.WriteLine("");

                int selection = Validation.GetInt(0, 3, "Please enter your selection number: ");

                switch (selection)
                {
                    case 1:
                        {
                            DBconnection.SelectBars(1, 0, 1, 1);

                        }
                        break;
                    case 2:
                        {
                            DBconnection.SelectBars(1, 0, 1, 2);
                            Utility.WaitForSeconds(2);

                            Console.ReadKey();

                            Console.Clear();
                        }
                        break;
                    case 3:
                        {
                            DBconnection.SelectBars(3, 0, 1, 3);
                            Utility.WaitForSeconds(2);

                            Console.ReadKey();

                            Console.Clear();
                        }
                        break;

                    case 0:
                        {
                            isBarMenu = false;
                            MainMenu();
                        }
                        break;
                }
            }

        }

        private void RatingSystemMenu()
        {
            bool isRatingMenu = true;

            while (isRatingMenu)
            {
                Console.Clear();

                Console.WriteLine("");
                Console.WriteLine("1. List the Restaurants Alphabetically Please.");//show rating next to name
                Console.WriteLine("2. List the Restaurants in Reverse Alphabetical Please.");
                Console.WriteLine("3. Sort the Restaurants from Best to Worst Please.");
                Console.WriteLine("4. Sort the Restaurants from Worst to Best Please.");
                Console.WriteLine("5. Only View X and up Please.");
                Console.WriteLine("0. Back");
                Console.WriteLine("");

                int selection = Validation.GetInt(0, 5, "Please enter your selection number: ");

                switch (selection)
                {
                    case 1:
                        {
                            //1. List Restaurants Alphabetically.");//show rating next to name
                            DBconnection.SelectReviews(1, 5, 2);
                        }
                        break;
                    case 2:
                        {
                            //"2. List Restaurants in Reverse Alphabetical."
                            DBconnection.SelectReviews(2, 5, 2);
                        }
                        break;
                    case 3:
                        {
                            //"3. Sort Restaurants from Best to worst.
                            DBconnection.SelectReviews(3, 5, 2);
                        }
                        break;
                    case 4:
                        {
                            //"4. Sort Restaurants from Worst to best."
                            DBconnection.SelectReviews(4, 5, 2);
                        }
                        break;
                    case 5:
                        {
                            RatingSystemByStarsMenu();
                        }
                        break;
                    case 0:
                        {
                            isRatingMenu = false;
                        }
                        break;
                }
            }

        }

        private void RatingSystemByStarsMenu()
        {
            bool isRatingByStarsMenu = true;

            while (isRatingByStarsMenu)
            {
                Console.Clear();

                Console.WriteLine("");
                Console.WriteLine("1. Show the best (5 Stars) Please. ");
                Console.WriteLine("2. Show 4 Stars and above Please. ");
                Console.WriteLine("3. Show 3 Stars and above Please. ");
                Console.WriteLine("4. Show the Worst (1 Stars) Please. ");
                Console.WriteLine("5. Show Unrated Please. ");
                Console.WriteLine("0. Back.");
                Console.WriteLine("");

                int selection = Validation.GetInt(0, 5, "Please enter your selection number: ");

                switch (selection)
                {
                    case 1:
                        {
                            //1. 5 
                            DBconnection.SelectReviews(0, 5, 3);
                        }
                        break;
                    case 2:
                        {
                            //"2. 4 and above
                            DBconnection.SelectReviews(0, 4, 1);
                        }
                        break;
                    case 3:
                        {
                            //"3. 3 and above
                            DBconnection.SelectReviews(0, 3, 1);
                        }
                        break;
                    case 4:
                        {
                            //"4. 1 only
                            DBconnection.SelectReviews(0, 1, 3);
                        }
                        break;
                    case 5:
                        {
                            //"5. unrated
                            DBconnection.SelectReviews(0, 0, 3);
                        }
                        break;
                    case 0:
                        {
                            isRatingByStarsMenu = false;
                            RatingSystemMenu();
                        }
                        break;
                }
            }
        }

        private void PlayCardGame()
        {
            int[] deck = new int[] { 1,1,1,1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 8, 9, 9, 9, 9, 10, 10, 10, 10, 11, 11, 11, 11, 12, 12, 12, 12, 13, 13, 13, 13 };
            List<Player> players = new List<Player>();
            Player player1 = new Player(); 
            Player player2 = new Player(); 
            Player player3 = new Player(); 
            Player player4 = new Player(); 
            Random rnd = new Random();


            int playerRandom = rnd.Next(1, 25);
            player1.PlayerName = (DBconnection.GetPlayer(playerRandom));
            int playerRandom2 = rnd.Next(25, 50);
            player2.PlayerName = (DBconnection.GetPlayer(playerRandom2));
            int playerRandom3 = rnd.Next(50, 75);
            player3.PlayerName = (DBconnection.GetPlayer(playerRandom3));
            int playerRandom4 = rnd.Next(75, 101);
            player4.PlayerName = (DBconnection.GetPlayer(playerRandom4));
            
            players.Add(player1); players.Add(player2); players.Add(player3); players.Add(player4);
            
            
            foreach (int dcard in deck)
            {
                bool cardsLeft = true;
                while(cardsLeft)
                {
                    int playerNumber = rnd.Next(0, 4);

                    if(players[playerNumber].Cards.Count <= 12)
                    {
                        players[playerNumber].Cards.Add(dcard);
                        cardsLeft = false;
                    }

                    if(players[0].Cards.Count >= 13 && players[1].Cards.Count >= 13 && players[2].Cards.Count >= 13 && players[3].Cards.Count >= 13)
                    {
                        cardsLeft = false;
                    }
                    
                }
            }

            Console.Clear();
            players.Sort(Player.SortRatingDescending());
            foreach (Player playerInst in players)
            {
                Console.WriteLine($"{playerInst.PlayerName}'s Score"); 
                foreach (int cardInt in playerInst.Cards)
                Console.Write($"{cardInt.ToString()} ");
                Console.WriteLine("");
                Console.WriteLine($"----Total Score = {playerInst.Score()}----");
                Console.WriteLine("");

            }

            Utility.WaitForKey("Press any key to return to the menu.");
            

        }
            
        

    
    }
}
