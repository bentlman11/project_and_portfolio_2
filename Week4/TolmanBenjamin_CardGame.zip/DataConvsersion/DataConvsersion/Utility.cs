﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data.MySqlClient;
using System.Timers;

namespace DataConvsersion
{
   
    //various small utilities for ease.
    class Utility
    {
        private static int _timerCounter = 0;
        private static int _timerMax = 0;
        private static Timer timer;

        public static int TimerCounter
        {
            get { return _timerCounter; } set { _timerCounter = value; }
        }

        public static void WaitForKey(string message)
        {
            Console.WriteLine("");
            Console.WriteLine(message);
            Console.ReadKey();
        }

        public static string NullChecker(MySqlDataReader rdr, int columnNumber)
        {
            if (!rdr.IsDBNull(columnNumber))
            {
                return rdr.GetString(columnNumber).ToLower();
            }
            return "";
        }

        public static int NullCheckerInt(MySqlDataReader rdr, int columnNumber)
        {
            if (!rdr.IsDBNull(columnNumber))
            {
                int temp = 0;

                temp = rdr.GetInt16(columnNumber);

                return temp;
            }

            else
            {

                return 0;
            }
        }

        public static decimal NullCheckerDecimal(MySqlDataReader rdr, int columnNumber)
        {
            if (!rdr.IsDBNull(columnNumber))
            {
                decimal temp = rdr.GetDecimal(columnNumber);
                return temp;
            }

            else
            {
                return 0.0m;
            }
        }

        public static double NullCheckerDouble(MySqlDataReader rdr, int columnNumber)
        {
            if (!rdr.IsDBNull(columnNumber))
            {
                double temp = rdr.GetDouble(columnNumber);
                return temp;
            }

            else
            {
                return 0.0;
            }
        }

        public static void WaitForSeconds(float seconds)
        {
            //Set time to happen really fast 1,000 = 1 second
            //Start the function every 1000/1000 seconds
            timer = new Timer(50);

            //At 50/1000, run this method "OnTimedEvent"
            //Every time it elapses, do it
            timer.Elapsed += OnTimedEvent;

            //Reset timer again after 50/1000, over and over again
            //False means to only run the timer one time
            timer.AutoReset = true;

            //The timer is enabled so it will work
            //False means the timer will not work
            timer.Enabled = true;
        }

        private static void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            //turn off the curser
            Console.CursorVisible = false;

            TimerCounter++;
            
            if (TimerCounter == _timerMax)
            {
                //Stop Timer
                timer.Stop();
                
                Console.CursorVisible = true;
            }
        }

    }
}
